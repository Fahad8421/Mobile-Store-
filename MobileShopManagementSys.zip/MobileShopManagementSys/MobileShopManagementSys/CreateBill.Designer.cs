﻿namespace MobileShopManagementSys
{
    partial class CreateBill
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtqt = new System.Windows.Forms.TextBox();
            this.txtQty = new System.Windows.Forms.Label();
            this.dataGridViewAddToCard = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnAddToCard = new System.Windows.Forms.Button();
            this.lblpid = new System.Windows.Forms.Label();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.txtAProduct = new System.Windows.Forms.TextBox();
            this.txtpmodel = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.btnProRefresh = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.cbProduct = new System.Windows.Forms.ComboBox();
            this.txtMobno = new System.Windows.Forms.TextBox();
            this.txtCustName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.CalenderBill = new System.Windows.Forms.DateTimePicker();
            this.txtAdvance = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtFinalTotal = new System.Windows.Forms.TextBox();
            this.txtSubTotal = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.deleteDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.btnNewInventory = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAddToCard)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtAddress
            // 
            this.txtAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.txtAddress.Location = new System.Drawing.Point(289, 165);
            this.txtAddress.Multiline = true;
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(391, 76);
            this.txtAddress.TabIndex = 26;
            // 
            // txtqt
            // 
            this.txtqt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.txtqt.Location = new System.Drawing.Point(289, 532);
            this.txtqt.Multiline = true;
            this.txtqt.Name = "txtqt";
            this.txtqt.Size = new System.Drawing.Size(187, 35);
            this.txtqt.TabIndex = 57;
            this.txtqt.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtqt_KeyPress);
            // 
            // txtQty
            // 
            this.txtQty.AutoSize = true;
            this.txtQty.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQty.Location = new System.Drawing.Point(185, 532);
            this.txtQty.Name = "txtQty";
            this.txtQty.Size = new System.Drawing.Size(68, 24);
            this.txtQty.TabIndex = 56;
            this.txtQty.Text = "Quntity";
            // 
            // dataGridViewAddToCard
            // 
            this.dataGridViewAddToCard.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewAddToCard.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6});
            this.dataGridViewAddToCard.Location = new System.Drawing.Point(31, 652);
            this.dataGridViewAddToCard.Name = "dataGridViewAddToCard";
            this.dataGridViewAddToCard.RowTemplate.Height = 24;
            this.dataGridViewAddToCard.Size = new System.Drawing.Size(690, 191);
            this.dataGridViewAddToCard.TabIndex = 46;
            this.dataGridViewAddToCard.CellMouseUp += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridViewAddToCard_CellMouseUp);
            this.dataGridViewAddToCard.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridViewAddToCard_RowHeaderMouseClick);
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column1.HeaderText = "PID";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column2.HeaderText = "Product";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column3.HeaderText = "Model";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column4.HeaderText = "Qty";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column5.HeaderText = "Price";
            this.Column5.Name = "Column5";
            // 
            // Column6
            // 
            this.Column6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column6.HeaderText = "Total";
            this.Column6.Name = "Column6";
            // 
            // btnAddToCard
            // 
            this.btnAddToCard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(134)))), ((int)(((byte)(244)))));
            this.btnAddToCard.FlatAppearance.BorderSize = 0;
            this.btnAddToCard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddToCard.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.btnAddToCard.ForeColor = System.Drawing.Color.White;
            this.btnAddToCard.Location = new System.Drawing.Point(270, 592);
            this.btnAddToCard.Name = "btnAddToCard";
            this.btnAddToCard.Size = new System.Drawing.Size(226, 43);
            this.btnAddToCard.TabIndex = 55;
            this.btnAddToCard.Text = "Add To Card";
            this.btnAddToCard.UseVisualStyleBackColor = false;
            this.btnAddToCard.Click += new System.EventHandler(this.btnAddToCard_Click);
            // 
            // lblpid
            // 
            this.lblpid.AutoSize = true;
            this.lblpid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpid.Location = new System.Drawing.Point(530, 474);
            this.lblpid.Name = "lblpid";
            this.lblpid.Size = new System.Drawing.Size(27, 24);
            this.lblpid.TabIndex = 54;
            this.lblpid.Text = "ID";
            // 
            // txtPrice
            // 
            this.txtPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.txtPrice.Location = new System.Drawing.Point(289, 463);
            this.txtPrice.Multiline = true;
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(187, 35);
            this.txtPrice.TabIndex = 53;
            this.txtPrice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPrice_KeyPress);
            // 
            // txtAProduct
            // 
            this.txtAProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.txtAProduct.Location = new System.Drawing.Point(290, 402);
            this.txtAProduct.Multiline = true;
            this.txtAProduct.Name = "txtAProduct";
            this.txtAProduct.Size = new System.Drawing.Size(324, 35);
            this.txtAProduct.TabIndex = 52;
            // 
            // txtpmodel
            // 
            this.txtpmodel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.txtpmodel.Location = new System.Drawing.Point(290, 338);
            this.txtpmodel.Multiline = true;
            this.txtpmodel.Name = "txtpmodel";
            this.txtpmodel.Size = new System.Drawing.Size(324, 35);
            this.txtpmodel.TabIndex = 31;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(185, 466);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 24);
            this.label12.TabIndex = 51;
            this.label12.Text = "Price";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(116, 405);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(137, 24);
            this.label11.TabIndex = 50;
            this.label11.Text = "Available Stock";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(175, 349);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(63, 24);
            this.label10.TabIndex = 49;
            this.label10.Text = "Model";
            // 
            // btnProRefresh
            // 
            this.btnProRefresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(134)))), ((int)(((byte)(244)))));
            this.btnProRefresh.FlatAppearance.BorderSize = 0;
            this.btnProRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnProRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProRefresh.ForeColor = System.Drawing.Color.White;
            this.btnProRefresh.Location = new System.Drawing.Point(644, 277);
            this.btnProRefresh.Name = "btnProRefresh";
            this.btnProRefresh.Size = new System.Drawing.Size(115, 30);
            this.btnProRefresh.TabIndex = 48;
            this.btnProRefresh.Text = "Refresh";
            this.btnProRefresh.UseVisualStyleBackColor = false;
            this.btnProRefresh.Click += new System.EventHandler(this.btnProRefresh_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(116, 280);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(132, 24);
            this.label9.TabIndex = 46;
            this.label9.Text = "Select Product";
            // 
            // cbProduct
            // 
            this.cbProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.cbProduct.FormattingEnabled = true;
            this.cbProduct.Location = new System.Drawing.Point(289, 277);
            this.cbProduct.Name = "cbProduct";
            this.cbProduct.Size = new System.Drawing.Size(320, 30);
            this.cbProduct.TabIndex = 47;
            this.cbProduct.SelectedIndexChanged += new System.EventHandler(this.cbProduct_SelectedIndexChanged);
            // 
            // txtMobno
            // 
            this.txtMobno.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.txtMobno.Location = new System.Drawing.Point(289, 110);
            this.txtMobno.Multiline = true;
            this.txtMobno.Name = "txtMobno";
            this.txtMobno.Size = new System.Drawing.Size(391, 35);
            this.txtMobno.TabIndex = 25;
            // 
            // txtCustName
            // 
            this.txtCustName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.txtCustName.Location = new System.Drawing.Point(289, 50);
            this.txtCustName.Multiline = true;
            this.txtCustName.Name = "txtCustName";
            this.txtCustName.Size = new System.Drawing.Size(391, 35);
            this.txtCustName.TabIndex = 24;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(158, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 24);
            this.label3.TabIndex = 4;
            this.label3.Text = "Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(158, 165);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 24);
            this.label5.TabIndex = 8;
            this.label5.Text = "Address";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(151, 113);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 24);
            this.label4.TabIndex = 6;
            this.label4.Text = "Mobile No";
            // 
            // CalenderBill
            // 
            this.CalenderBill.CustomFormat = "MM-dd-yyyy";
            this.CalenderBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.CalenderBill.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.CalenderBill.Location = new System.Drawing.Point(869, 13);
            this.CalenderBill.Name = "CalenderBill";
            this.CalenderBill.Size = new System.Drawing.Size(162, 28);
            this.CalenderBill.TabIndex = 67;
            // 
            // txtAdvance
            // 
            this.txtAdvance.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.txtAdvance.Location = new System.Drawing.Point(939, 641);
            this.txtAdvance.Multiline = true;
            this.txtAdvance.Name = "txtAdvance";
            this.txtAdvance.Size = new System.Drawing.Size(274, 35);
            this.txtAdvance.TabIndex = 33;
            this.txtAdvance.TextChanged += new System.EventHandler(this.txtAdvance_TextChanged);
            this.txtAdvance.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAdvance_KeyPress);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(809, 700);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(97, 24);
            this.label15.TabIndex = 58;
            this.label15.Text = "Final Total";
            // 
            // txtFinalTotal
            // 
            this.txtFinalTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.txtFinalTotal.Location = new System.Drawing.Point(939, 697);
            this.txtFinalTotal.Multiline = true;
            this.txtFinalTotal.Name = "txtFinalTotal";
            this.txtFinalTotal.ReadOnly = true;
            this.txtFinalTotal.Size = new System.Drawing.Size(364, 35);
            this.txtFinalTotal.TabIndex = 59;
            this.txtFinalTotal.Text = "0";
            // 
            // txtSubTotal
            // 
            this.txtSubTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.txtSubTotal.Location = new System.Drawing.Point(939, 582);
            this.txtSubTotal.Multiline = true;
            this.txtSubTotal.Name = "txtSubTotal";
            this.txtSubTotal.ReadOnly = true;
            this.txtSubTotal.Size = new System.Drawing.Size(364, 35);
            this.txtSubTotal.TabIndex = 56;
            this.txtSubTotal.Text = "0";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(821, 644);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(83, 24);
            this.label14.TabIndex = 57;
            this.label14.Text = "Discount";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(784, 585);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(141, 24);
            this.label13.TabIndex = 56;
            this.label13.Text = "Estimat Amount";
            // 
            // deleteDataToolStripMenuItem
            // 
            this.deleteDataToolStripMenuItem.Name = "deleteDataToolStripMenuItem";
            this.deleteDataToolStripMenuItem.Size = new System.Drawing.Size(158, 24);
            this.deleteDataToolStripMenuItem.Text = "Delete Data";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteDataToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(159, 28);
            this.contextMenuStrip1.Click += new System.EventHandler(this.contextMenuStrip1_Click);
            // 
            // btnNewInventory
            // 
            this.btnNewInventory.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(134)))), ((int)(((byte)(244)))));
            this.btnNewInventory.FlatAppearance.BorderSize = 0;
            this.btnNewInventory.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNewInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.btnNewInventory.ForeColor = System.Drawing.Color.White;
            this.btnNewInventory.Location = new System.Drawing.Point(1079, 774);
            this.btnNewInventory.Name = "btnNewInventory";
            this.btnNewInventory.Size = new System.Drawing.Size(178, 55);
            this.btnNewInventory.TabIndex = 66;
            this.btnNewInventory.Text = "New Inventory";
            this.btnNewInventory.UseVisualStyleBackColor = false;
            this.btnNewInventory.Click += new System.EventHandler(this.btnNewInventory_Click);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(134)))), ((int)(((byte)(244)))));
            this.btnSave.FlatAppearance.BorderSize = 0;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(813, 774);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(184, 55);
            this.btnSave.TabIndex = 65;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Mongolian Baiti", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(568, 5);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(173, 36);
            this.label7.TabIndex = 82;
            this.label7.Text = "Create Bill";
            // 
            // CreateBill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.txtFinalTotal);
            this.Controls.Add(this.dataGridViewAddToCard);
            this.Controls.Add(this.txtAdvance);
            this.Controls.Add(this.txtqt);
            this.Controls.Add(this.txtSubTotal);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.btnAddToCard);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtQty);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.txtMobno);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblpid);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtAProduct);
            this.Controls.Add(this.txtCustName);
            this.Controls.Add(this.txtpmodel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.CalenderBill);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.btnProRefresh);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.btnNewInventory);
            this.Controls.Add(this.cbProduct);
            this.Controls.Add(this.btnSave);
            this.Name = "CreateBill";
            this.Size = new System.Drawing.Size(1494, 864);
            this.Load += new System.EventHandler(this.CreateBill_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAddToCard)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtqt;
        private System.Windows.Forms.Label txtQty;
        private System.Windows.Forms.DataGridView dataGridViewAddToCard;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.Button btnAddToCard;
        private System.Windows.Forms.Label lblpid;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.TextBox txtAProduct;
        private System.Windows.Forms.TextBox txtpmodel;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnProRefresh;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cbProduct;
        private System.Windows.Forms.TextBox txtMobno;
        private System.Windows.Forms.TextBox txtCustName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker CalenderBill;
        private System.Windows.Forms.TextBox txtAdvance;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtFinalTotal;
        private System.Windows.Forms.TextBox txtSubTotal;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ToolStripMenuItem deleteDataToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Button btnNewInventory;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label7;
    }
}
