﻿namespace MobileShopManagementSys
{
    partial class BillData
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSaleid = new System.Windows.Forms.Label();
            this.lblcid = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnCustRefresh = new System.Windows.Forms.Button();
            this.cbData = new System.Windows.Forms.ComboBox();
            this.lblMobno = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblto = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.lblDate = new System.Windows.Forms.Label();
            this.crystalReportViewer1 = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.SuspendLayout();
            // 
            // lblSaleid
            // 
            this.lblSaleid.AutoSize = true;
            this.lblSaleid.Location = new System.Drawing.Point(928, 217);
            this.lblSaleid.Name = "lblSaleid";
            this.lblSaleid.Size = new System.Drawing.Size(46, 17);
            this.lblSaleid.TabIndex = 88;
            this.lblSaleid.Text = "label2";
            this.lblSaleid.Visible = false;
            // 
            // lblcid
            // 
            this.lblcid.AutoSize = true;
            this.lblcid.Location = new System.Drawing.Point(792, 218);
            this.lblcid.Name = "lblcid";
            this.lblcid.Size = new System.Drawing.Size(46, 17);
            this.lblcid.TabIndex = 87;
            this.lblcid.Text = "label1";
            this.lblcid.Visible = false;
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(134)))), ((int)(((byte)(244)))));
            this.btnSearch.FlatAppearance.BorderSize = 0;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.btnSearch.ForeColor = System.Drawing.Color.White;
            this.btnSearch.Location = new System.Drawing.Point(309, 270);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(184, 55);
            this.btnSearch.TabIndex = 86;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnCustRefresh
            // 
            this.btnCustRefresh.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(134)))), ((int)(((byte)(244)))));
            this.btnCustRefresh.FlatAppearance.BorderSize = 0;
            this.btnCustRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCustRefresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustRefresh.ForeColor = System.Drawing.Color.White;
            this.btnCustRefresh.Location = new System.Drawing.Point(616, 142);
            this.btnCustRefresh.Name = "btnCustRefresh";
            this.btnCustRefresh.Size = new System.Drawing.Size(144, 41);
            this.btnCustRefresh.TabIndex = 85;
            this.btnCustRefresh.Text = "Refresh";
            this.btnCustRefresh.UseVisualStyleBackColor = false;
            this.btnCustRefresh.Click += new System.EventHandler(this.btnCustRefresh_Click);
            // 
            // cbData
            // 
            this.cbData.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.cbData.FormattingEnabled = true;
            this.cbData.Location = new System.Drawing.Point(322, 142);
            this.cbData.Name = "cbData";
            this.cbData.Size = new System.Drawing.Size(261, 30);
            this.cbData.TabIndex = 84;
            this.cbData.SelectedIndexChanged += new System.EventHandler(this.cbData_SelectedIndexChanged);
            // 
            // lblMobno
            // 
            this.lblMobno.AutoSize = true;
            this.lblMobno.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMobno.ForeColor = System.Drawing.Color.Black;
            this.lblMobno.Location = new System.Drawing.Point(112, 142);
            this.lblMobno.Name = "lblMobno";
            this.lblMobno.Size = new System.Drawing.Size(204, 24);
            this.lblMobno.TabIndex = 83;
            this.lblMobno.Text = "Select Customer Name";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Mongolian Baiti", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(672, 58);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(147, 36);
            this.label7.TabIndex = 82;
            this.label7.Text = "Bill Data";
            // 
            // lblto
            // 
            this.lblto.AutoSize = true;
            this.lblto.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblto.ForeColor = System.Drawing.Color.Black;
            this.lblto.Location = new System.Drawing.Point(456, 212);
            this.lblto.Name = "lblto";
            this.lblto.Size = new System.Drawing.Size(37, 24);
            this.lblto.TabIndex = 81;
            this.lblto.Text = "TO";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.Location = new System.Drawing.Point(508, 212);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(149, 28);
            this.dateTimePicker2.TabIndex = 80;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "yyyy-MM-dd";
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(292, 212);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(149, 28);
            this.dateTimePicker1.TabIndex = 79;
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.ForeColor = System.Drawing.Color.Black;
            this.lblDate.Location = new System.Drawing.Point(135, 217);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(105, 24);
            this.lblDate.TabIndex = 78;
            this.lblDate.Text = "Select Date";
            // 
            // crystalReportViewer1
            // 
            this.crystalReportViewer1.ActiveViewIndex = -1;
            this.crystalReportViewer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crystalReportViewer1.Cursor = System.Windows.Forms.Cursors.Default;
            this.crystalReportViewer1.DisplayStatusBar = false;
            this.crystalReportViewer1.Location = new System.Drawing.Point(24, 343);
            this.crystalReportViewer1.Name = "crystalReportViewer1";
            this.crystalReportViewer1.Size = new System.Drawing.Size(1325, 488);
            this.crystalReportViewer1.TabIndex = 89;
            this.crystalReportViewer1.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None;
            // 
            // BillData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.crystalReportViewer1);
            this.Controls.Add(this.lblSaleid);
            this.Controls.Add(this.lblcid);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.btnCustRefresh);
            this.Controls.Add(this.cbData);
            this.Controls.Add(this.lblMobno);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lblto);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.lblDate);
            this.Name = "BillData";
            this.Size = new System.Drawing.Size(1536, 864);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSaleid;
        private System.Windows.Forms.Label lblcid;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnCustRefresh;
        private System.Windows.Forms.ComboBox cbData;
        private System.Windows.Forms.Label lblMobno;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblto;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label lblDate;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer crystalReportViewer1;
    }
}
