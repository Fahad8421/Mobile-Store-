﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MobileShopManagementSys
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnLogIn_Click(object sender, EventArgs e)
        {
            if (txtUname.Text == "Admin" && txtPass.Text == "Pass123")
            {
                MessageBox.Show("Welcome to Mobile Shop Management System");
                this.Hide();
                MainForm ob = new MainForm();
                ob.Show();
            }
            else
            {
                MessageBox.Show("Please Check User name and Password");
                txtUname.Text = "";
                txtPass.Text = "";
                txtUname.Focus();

            }
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            txtUname.Text = "";
            txtPass.Text = "";
            txtUname.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
