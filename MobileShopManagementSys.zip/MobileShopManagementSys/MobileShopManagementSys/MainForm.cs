﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MobileShopManagementSys
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Maximized;
            /*string w, h;
            w = Screen.PrimaryScreen.Bounds.Width.ToString();
            h = Screen.PrimaryScreen.Bounds.Height.ToString();
            label2.Text = ("Resolution" + w + "x" + h);*/
        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            panelMini.Height = btnDashboard.Height;
            panelMini.Top = btnDashboard.Top;
            dashboard1.BringToFront();
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            panelMini.Height = btnAddProduct.Height;
            panelMini.Top = btnAddProduct.Top;
            addProduct1.BringToFront();
        }

        private void btnCreateBill_Click(object sender, EventArgs e)
        {
            panelMini.Height = btnCreateBill.Height;
            panelMini.Top = btnCreateBill.Top;
            createBill1.BringToFront();
        }

        private void btnBillData_Click(object sender, EventArgs e)
        {
            panelMini.Height = btnBillData.Height;
            panelMini.Top = btnBillData.Top;
            billData1.BringToFront();
        }

        private void btnStockData_Click(object sender, EventArgs e)
        {
            panelMini.Height = btnStockData.Height;
            panelMini.Top = btnStockData.Top;
            viewStock1.BringToFront();
        }

        private void btnAboutUs_Click(object sender, EventArgs e)
        {
            panelMini.Height = btnAboutUs.Height;
            panelMini.Top = btnAboutUs.Top;
            aboutUs1.BringToFront();

        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            panelMini.Height = btnLogout.Height;
            panelMini.Top = btnLogout.Top;
            this.Close();
            LoginForm ob = new LoginForm();
            ob.Show();
        }
    }
}
