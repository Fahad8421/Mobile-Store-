﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace MobileShopManagementSys
{
    public partial class CreateBill : UserControl
    {
        public CreateBill()
        {
            InitializeComponent();
        }

        private void CreateBill_Load(object sender, EventArgs e)
        {

        }
        public void Stock()
        {
            try
            {
                cbProduct.Items.Clear();
                string constring = ConfigurationManager.ConnectionStrings["MyConnection"].ToString();
                SqlConnection con = new SqlConnection(constring);
                //DataTable donater = new DataTable();
                con.Open();
                SqlCommand cmd = new SqlCommand("select cname from tbl_Product ", con);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    cbProduct.Items.Add(dr[0].ToString());
                }

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnProRefresh_Click(object sender, EventArgs e)
        {
            Stock();
        }

        private void cbProduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                string constring = ConfigurationManager.ConnectionStrings["MyConnection"].ToString();
                SqlConnection con = new SqlConnection(constring);
                string sql = "select pid,cname,date,model,qty,price from tbl_Product where cname='" + cbProduct.Text + "'";
                SqlCommand cmd = new SqlCommand(sql, con);

                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                //  SqlCommand cmd = new SqlCommand(sql, con);
                int x = cmd.ExecuteNonQuery();
                SqlDataReader dr = cmd.ExecuteReader();


                if (dr.Read())
                {
                    cbProduct.Text = dr["cname"].ToString();
                    txtpmodel.Text = dr["model"].ToString();
                    txtAProduct.Text = dr["qty"].ToString();
                    txtPrice.Text = dr["price"].ToString();

                    lblpid.Text = dr["pid"].ToString();


                }
                else
                {
                    MessageBox.Show("Data not Availebel");


                }
                con.Close();
            }


            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        public int aqt = 0;

        private void btnAddToCard_Click(object sender, EventArgs e)
        {
            int ava, qt;
            if (txtqt.Text == "")
            {
                qt = 0;

            }
            else
            {
                ava = Convert.ToInt32(txtAProduct.Text);
                qt = Convert.ToInt32(txtqt.Text);
                if (qt > ava)
                {
                    string msg1 = "Please Insert Valid Quntity OR Stock is not available";
                    string msg2 = "Billing";
                    MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                    DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                    txtqt.Focus();
                    return;
                }
            }
            if (cbProduct.Text == "")
            {
                string msg1 = "Please Select Product";
                string msg2 = "Product Data";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                btnProRefresh.Focus();
                return;
            }
            if (txtqt.Text == "")
            {
                string msg1 = "Please Insert Quntity";
                string msg2 = "Add Product";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                txtqt.Focus();
                return;
            }

            int n = dataGridViewAddToCard.Rows.Add();
            dataGridViewAddToCard.Rows[n].Cells[0].Value = lblpid.Text;
            dataGridViewAddToCard.Rows[n].Cells[1].Value = cbProduct.Text;
            dataGridViewAddToCard.Rows[n].Cells[2].Value = txtpmodel.Text;
            dataGridViewAddToCard.Rows[n].Cells[3].Value = txtqt.Text;
            dataGridViewAddToCard.Rows[n].Cells[4].Value = txtPrice.Text;

            int p, q, temp, total;
            p = Convert.ToInt32(txtPrice.Text);
            q = Convert.ToInt32(txtqt.Text);

            temp = p * q;
            dataGridViewAddToCard.Rows[n].Cells[5].Value = temp.ToString();
            total = Convert.ToInt32(txtSubTotal.Text);
            total = total + temp;
            txtSubTotal.Text = total.ToString();
            try
            {
                int q1, q2, q3;
                q1 = Convert.ToInt32(txtAProduct.Text);
                q2 = Convert.ToInt32(txtqt.Text);
                q3 = q1 - q2;

                string constring = ConfigurationManager.ConnectionStrings["MyConnection"].ToString();
                SqlConnection con = new SqlConnection(constring);
                con.Open();
                string sql1 = "update tbl_Product set qty=@qty where pid=@pid";
                SqlCommand cmd2 = new SqlCommand(sql1, con);
                cmd2.Parameters.AddWithValue("@pid", lblpid.Text);

                cmd2.Parameters.AddWithValue("@qty", q3);
                aqt = q3;
                cmd2.ExecuteNonQuery();
                con.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            cbProduct.Text = "";
            txtpmodel.Text = "";
            txtAProduct.Text = "";
            txtPrice.Text = "";
            txtqt.Text = "";
            lblpid.Text = "";
        }
        private int rowIndex = 0;
        private void contextMenuStrip1_Click(object sender, EventArgs e)
        {
            if (cbProduct.Text == "")
            {
                string msg1 = "Please Select Product Data";
                string msg2 = "Product Data";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                btnProRefresh.Focus();
                return;
            }
            if (!this.dataGridViewAddToCard.Rows[this.rowIndex].IsNewRow)
            {


                this.dataGridViewAddToCard.Rows.RemoveAt(this.rowIndex);
                int p, q, temp, total;
                p = Convert.ToInt32(txtPrice.Text);
                q = Convert.ToInt32(txtqt.Text);
                temp = p * q;
                total = Convert.ToInt32(txtSubTotal.Text);
                total = total - temp;
                txtSubTotal.Text = total.ToString();
                try
                {
                    int q1, q2, q3;
                    q1 = Convert.ToInt32(txtAProduct.Text);
                    q2 = Convert.ToInt32(txtqt.Text);
                    q3 = q1 + q2;

                    string constring = ConfigurationManager.ConnectionStrings["MyConnection"].ToString();
                    SqlConnection con = new SqlConnection(constring);
                    con.Open();
                    string sql1 = "update tbl_Product set qty=@qty where pid=@pid";
                    SqlCommand cmd2 = new SqlCommand(sql1, con);
                    cmd2.Parameters.AddWithValue("@pid", lblpid.Text);

                    cmd2.Parameters.AddWithValue("@qty", q3);

                    cmd2.ExecuteNonQuery();
                    con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                cbProduct.Text = "";
                txtpmodel.Text = "";
                txtAProduct.Text = "";
                txtPrice.Text = "";
                txtqt.Text = "";
                lblpid.Text = "";


            }
        }

        private void dataGridViewAddToCard_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {

                this.dataGridViewAddToCard.Rows[e.RowIndex].Selected = true;

                this.rowIndex = e.RowIndex;

                this.dataGridViewAddToCard.CurrentCell = this.dataGridViewAddToCard.Rows[e.RowIndex].Cells[1];

                this.contextMenuStrip1.Show(this.dataGridViewAddToCard, e.Location);

                contextMenuStrip1.Show(Cursor.Position);

            }
        }

        private void txtAdvance_TextChanged(object sender, EventArgs e)
        {
            int sub, adv, fin;
            if (txtAdvance.Text == "")
            {
                adv = 0;
            }
            else
            {
                sub = Convert.ToInt32(txtSubTotal.Text);
                adv = Convert.ToInt32(txtAdvance.Text);
                fin = sub - adv;
                txtFinalTotal.Text = fin.ToString();
            }
        }
        public void ClearData()
        {
            txtCustName.Text = "";
            txtMobno.Text = "";
            txtAddress.Text = "";
           // cbCompanyType.Text = "";
           // txtComapnyName.Text = "";
            //txtModel.Text = "";
            //txtProblem.Text = "";
            //txtIMEICode.Text = "";
           // lblYear.Text = "--";
           //// lblMonth.Text = "--";
           // lblDay.Text = "--";
            cbProduct.Text = "";
            txtpmodel.Text = "";
            txtAProduct.Text = "";
            txtPrice.Text = "";
            txtqt.Text = "";
            txtSubTotal.Text = "0";
            txtAdvance.Text = "";
            txtFinalTotal.Text = "0";
            lblpid.Text = "";
           // txtSamModel.Text = "";
            dataGridViewAddToCard.Rows.Clear();

        }

        private void dataGridViewAddToCard_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            lblpid.Text = dataGridViewAddToCard.Rows[e.RowIndex].Cells[0].Value.ToString();
            cbProduct.Text = dataGridViewAddToCard.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtpmodel.Text = dataGridViewAddToCard.Rows[e.RowIndex].Cells[2].Value.ToString();
            txtqt.Text = dataGridViewAddToCard.Rows[e.RowIndex].Cells[3].Value.ToString();
            txtPrice.Text = dataGridViewAddToCard.Rows[e.RowIndex].Cells[4].Value.ToString();
            try
            {

                string constring = ConfigurationManager.ConnectionStrings["MyConnection"].ToString();
                SqlConnection con = new SqlConnection(constring);
                string sql = "select qty from tbl_Product where cname='" + cbProduct.Text + "'";
                SqlCommand cmd = new SqlCommand(sql, con);

                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                //  SqlCommand cmd = new SqlCommand(sql, con);
                int x = cmd.ExecuteNonQuery();
                SqlDataReader dr = cmd.ExecuteReader();


                if (dr.Read())
                {

                    txtAProduct.Text = dr["qty"].ToString();



                }
                else
                {
                    MessageBox.Show("Data not Availebel");


                }
                con.Close();
            }


            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        int lastsid;

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtCustName.Text == "")
            {
                string msg1 = "Please Insert Customer Name";
                string msg2 = "Bill";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                txtCustName.Focus();
                return;
            }
            if (txtMobno.Text == "")
            {
                string msg1 = "Please Insert Mobile No.";
                string msg2 = "Bill";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                txtMobno.Focus();
                return;
            }
            if (txtAddress.Text == "")
            {
                string msg1 = "Please Insert Address";
                string msg2 = "Bill";
                MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                txtAddress.Focus();
                return;
            }

            
                try
                {

                    string constring = ConfigurationManager.ConnectionStrings["MyConnection"].ToString();
                    SqlConnection con = new SqlConnection(constring);
                    con.Open();

                    SqlCommand cmd1 = new SqlCommand("insert into tbl_Sale(total)values(@total) select @@identity;", con);

                    cmd1.Parameters.AddWithValue("@total", txtFinalTotal.Text);
                    lastsid = int.Parse(cmd1.ExecuteScalar().ToString());
                    string product, model, proid;
                    int price = 0;
                    int qty = 0;

                    int tot = 0;
                    int hsn = 0;
                    //int cid = Convert.ToInt32((lblCustID.Text).ToString());
                    for (int row = 0; row < dataGridViewAddToCard.Rows.Count - 1; row++)
                    {
                        proid = dataGridViewAddToCard.Rows[row].Cells[0].Value.ToString();
                        product = dataGridViewAddToCard.Rows[row].Cells[1].Value.ToString();
                        model = dataGridViewAddToCard.Rows[row].Cells[2].Value.ToString();
                        price = Convert.ToInt32(dataGridViewAddToCard.Rows[row].Cells[4].Value.ToString());
                        qty = int.Parse(dataGridViewAddToCard.Rows[row].Cells[3].Value.ToString());
                        tot = int.Parse(dataGridViewAddToCard.Rows[row].Cells[5].Value.ToString());


                        string sql = "insert into Bill values(@saleid,@custname,@mobno,@address,@product,@promodel,@qty,@price,@subtotal,@advance,@date)";
                        SqlCommand cmd = new SqlCommand(sql, con);
                        cmd.Parameters.AddWithValue("@saleid", lastsid);
                        cmd.Parameters.AddWithValue("@custname", txtCustName.Text);
                        cmd.Parameters.AddWithValue("@mobno", txtMobno.Text);
                        cmd.Parameters.AddWithValue("@address", txtAddress.Text);
                        cmd.Parameters.AddWithValue("@product", product);
                        cmd.Parameters.AddWithValue("@promodel", model);
                        cmd.Parameters.AddWithValue("@qty", qty);
                        cmd.Parameters.AddWithValue("@price", price);
                        cmd.Parameters.AddWithValue("@subtotal", tot);
                        cmd.Parameters.AddWithValue("@advance", txtAdvance.Text);
                        cmd.Parameters.AddWithValue("@date", CalenderBill.Text);

                        cmd.ExecuteNonQuery();
                        //int qty1=Convert.ToInt32(txtAProduct.Text);
                        // int qty2 = Convert.ToInt32(txtqt.Text);

                        string sql1 = "update tbl_Product set qty=@qty where pid=@pid";
                        SqlCommand cmd2 = new SqlCommand(sql1, con);
                        cmd2.Parameters.AddWithValue("@pid", proid);

                        cmd2.Parameters.AddWithValue("@qty", aqt);

                        cmd2.ExecuteNonQuery();

                    }

                    con.Close();
                 
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }           
              
            try
            {

                string constring = ConfigurationManager.ConnectionStrings["MyConnection"].ToString();
                SqlConnection con = new SqlConnection(constring);
                con.Open();
                string sql = "insert into tbl_Customer values(@custname,@mobno,@address)";
                SqlCommand cmd = new SqlCommand(sql, con);
                //cmd.Parameters.AddWithValue("@sid", lastsid);
                cmd.Parameters.AddWithValue("@custname", txtCustName.Text);
                cmd.Parameters.AddWithValue("@mobno", txtMobno.Text);
                cmd.Parameters.AddWithValue("@address", txtAddress.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record Inserted");
                ClearData();



            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnNewInventory_Click(object sender, EventArgs e)
        {
            ClearData();
        }

        private void txtPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;

            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void txtqt_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;

            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void txtAdvance_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;

            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
    }
}
