﻿namespace MobileShopManagementSys
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelLogo = new System.Windows.Forms.Panel();
            this.panelSideBar = new System.Windows.Forms.Panel();
            this.panelMini = new System.Windows.Forms.Panel();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnAboutUs = new System.Windows.Forms.Button();
            this.btnStockData = new System.Windows.Forms.Button();
            this.btnBillData = new System.Windows.Forms.Button();
            this.btnCreateBill = new System.Windows.Forms.Button();
            this.btnAddProduct = new System.Windows.Forms.Button();
            this.btnDashboard = new System.Windows.Forms.Button();
            this.panelTop = new System.Windows.Forms.Panel();
            this.panelData = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.dashboard1 = new MobileShopManagementSys.Dashboard();
            this.addProduct1 = new MobileShopManagementSys.AddProduct();
            this.createBill1 = new MobileShopManagementSys.CreateBill();
            this.billData1 = new MobileShopManagementSys.BillData();
            this.viewStock1 = new MobileShopManagementSys.ViewStock();
            this.aboutUs1 = new MobileShopManagementSys.AboutUs();
            this.panelLogo.SuspendLayout();
            this.panelSideBar.SuspendLayout();
            this.panelData.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panelLogo
            // 
            this.panelLogo.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panelLogo.Controls.Add(this.pictureBox1);
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Size = new System.Drawing.Size(212, 100);
            this.panelLogo.TabIndex = 0;
            // 
            // panelSideBar
            // 
            this.panelSideBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(134)))), ((int)(((byte)(244)))));
            this.panelSideBar.Controls.Add(this.panelMini);
            this.panelSideBar.Controls.Add(this.btnLogout);
            this.panelSideBar.Controls.Add(this.btnAboutUs);
            this.panelSideBar.Controls.Add(this.btnStockData);
            this.panelSideBar.Controls.Add(this.btnBillData);
            this.panelSideBar.Controls.Add(this.btnCreateBill);
            this.panelSideBar.Controls.Add(this.btnAddProduct);
            this.panelSideBar.Controls.Add(this.panelLogo);
            this.panelSideBar.Controls.Add(this.btnDashboard);
            this.panelSideBar.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSideBar.Location = new System.Drawing.Point(0, 0);
            this.panelSideBar.Name = "panelSideBar";
            this.panelSideBar.Size = new System.Drawing.Size(212, 764);
            this.panelSideBar.TabIndex = 1;
            // 
            // panelMini
            // 
            this.panelMini.BackColor = System.Drawing.Color.White;
            this.panelMini.Location = new System.Drawing.Point(0, 100);
            this.panelMini.Name = "panelMini";
            this.panelMini.Size = new System.Drawing.Size(11, 69);
            this.panelMini.TabIndex = 0;
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(134)))), ((int)(((byte)(244)))));
            this.btnLogout.FlatAppearance.BorderSize = 0;
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.btnLogout.ForeColor = System.Drawing.Color.White;
            this.btnLogout.Location = new System.Drawing.Point(0, 513);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(212, 69);
            this.btnLogout.TabIndex = 81;
            this.btnLogout.Text = "Log Out";
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // btnAboutUs
            // 
            this.btnAboutUs.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(134)))), ((int)(((byte)(244)))));
            this.btnAboutUs.FlatAppearance.BorderSize = 0;
            this.btnAboutUs.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAboutUs.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.btnAboutUs.ForeColor = System.Drawing.Color.White;
            this.btnAboutUs.Location = new System.Drawing.Point(0, 444);
            this.btnAboutUs.Name = "btnAboutUs";
            this.btnAboutUs.Size = new System.Drawing.Size(212, 69);
            this.btnAboutUs.TabIndex = 80;
            this.btnAboutUs.Text = "About Us";
            this.btnAboutUs.UseVisualStyleBackColor = false;
            this.btnAboutUs.Click += new System.EventHandler(this.btnAboutUs_Click);
            // 
            // btnStockData
            // 
            this.btnStockData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(134)))), ((int)(((byte)(244)))));
            this.btnStockData.FlatAppearance.BorderSize = 0;
            this.btnStockData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStockData.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.btnStockData.ForeColor = System.Drawing.Color.White;
            this.btnStockData.Location = new System.Drawing.Point(0, 375);
            this.btnStockData.Name = "btnStockData";
            this.btnStockData.Size = new System.Drawing.Size(212, 69);
            this.btnStockData.TabIndex = 79;
            this.btnStockData.Text = "Stock Data";
            this.btnStockData.UseVisualStyleBackColor = false;
            this.btnStockData.Click += new System.EventHandler(this.btnStockData_Click);
            // 
            // btnBillData
            // 
            this.btnBillData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(134)))), ((int)(((byte)(244)))));
            this.btnBillData.FlatAppearance.BorderSize = 0;
            this.btnBillData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBillData.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.btnBillData.ForeColor = System.Drawing.Color.White;
            this.btnBillData.Location = new System.Drawing.Point(0, 307);
            this.btnBillData.Name = "btnBillData";
            this.btnBillData.Size = new System.Drawing.Size(212, 69);
            this.btnBillData.TabIndex = 78;
            this.btnBillData.Text = "Bill Data";
            this.btnBillData.UseVisualStyleBackColor = false;
            this.btnBillData.Click += new System.EventHandler(this.btnBillData_Click);
            // 
            // btnCreateBill
            // 
            this.btnCreateBill.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(134)))), ((int)(((byte)(244)))));
            this.btnCreateBill.FlatAppearance.BorderSize = 0;
            this.btnCreateBill.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCreateBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.btnCreateBill.ForeColor = System.Drawing.Color.White;
            this.btnCreateBill.Location = new System.Drawing.Point(1, 238);
            this.btnCreateBill.Name = "btnCreateBill";
            this.btnCreateBill.Size = new System.Drawing.Size(212, 69);
            this.btnCreateBill.TabIndex = 77;
            this.btnCreateBill.Text = "Create Bill";
            this.btnCreateBill.UseVisualStyleBackColor = false;
            this.btnCreateBill.Click += new System.EventHandler(this.btnCreateBill_Click);
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(134)))), ((int)(((byte)(244)))));
            this.btnAddProduct.FlatAppearance.BorderSize = 0;
            this.btnAddProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddProduct.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.btnAddProduct.ForeColor = System.Drawing.Color.White;
            this.btnAddProduct.Location = new System.Drawing.Point(0, 169);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(212, 69);
            this.btnAddProduct.TabIndex = 76;
            this.btnAddProduct.Text = "Add Product";
            this.btnAddProduct.UseVisualStyleBackColor = false;
            this.btnAddProduct.Click += new System.EventHandler(this.btnAddProduct_Click);
            // 
            // btnDashboard
            // 
            this.btnDashboard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(134)))), ((int)(((byte)(244)))));
            this.btnDashboard.FlatAppearance.BorderSize = 0;
            this.btnDashboard.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDashboard.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F);
            this.btnDashboard.ForeColor = System.Drawing.Color.White;
            this.btnDashboard.Location = new System.Drawing.Point(0, 100);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Size = new System.Drawing.Size(212, 69);
            this.btnDashboard.TabIndex = 75;
            this.btnDashboard.Text = "DashBoard";
            this.btnDashboard.UseVisualStyleBackColor = false;
            this.btnDashboard.Click += new System.EventHandler(this.btnDashboard_Click);
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(212, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(1080, 100);
            this.panelTop.TabIndex = 2;
            // 
            // panelData
            // 
            this.panelData.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panelData.Controls.Add(this.dashboard1);
            this.panelData.Controls.Add(this.addProduct1);
            this.panelData.Controls.Add(this.createBill1);
            this.panelData.Controls.Add(this.billData1);
            this.panelData.Controls.Add(this.viewStock1);
            this.panelData.Controls.Add(this.aboutUs1);
            this.panelData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelData.Location = new System.Drawing.Point(212, 100);
            this.panelData.Name = "panelData";
            this.panelData.Size = new System.Drawing.Size(1080, 664);
            this.panelData.TabIndex = 3;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::MobileShopManagementSys.Properties.Resources.images;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(212, 100);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // dashboard1
            // 
            this.dashboard1.BackColor = System.Drawing.Color.White;
            this.dashboard1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dashboard1.Location = new System.Drawing.Point(0, 0);
            this.dashboard1.Name = "dashboard1";
            this.dashboard1.Size = new System.Drawing.Size(1080, 664);
            this.dashboard1.TabIndex = 5;
            // 
            // addProduct1
            // 
            this.addProduct1.BackColor = System.Drawing.Color.White;
            this.addProduct1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addProduct1.Location = new System.Drawing.Point(0, 0);
            this.addProduct1.Name = "addProduct1";
            this.addProduct1.Size = new System.Drawing.Size(1080, 664);
            this.addProduct1.TabIndex = 4;
            // 
            // createBill1
            // 
            this.createBill1.BackColor = System.Drawing.Color.White;
            this.createBill1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.createBill1.Location = new System.Drawing.Point(0, 0);
            this.createBill1.Name = "createBill1";
            this.createBill1.Size = new System.Drawing.Size(1080, 664);
            this.createBill1.TabIndex = 3;
            // 
            // billData1
            // 
            this.billData1.BackColor = System.Drawing.Color.White;
            this.billData1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.billData1.Location = new System.Drawing.Point(0, 0);
            this.billData1.Name = "billData1";
            this.billData1.Size = new System.Drawing.Size(1080, 664);
            this.billData1.TabIndex = 2;
            // 
            // viewStock1
            // 
            this.viewStock1.BackColor = System.Drawing.Color.White;
            this.viewStock1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.viewStock1.Location = new System.Drawing.Point(0, 0);
            this.viewStock1.Name = "viewStock1";
            this.viewStock1.Size = new System.Drawing.Size(1080, 664);
            this.viewStock1.TabIndex = 1;
            // 
            // aboutUs1
            // 
            this.aboutUs1.BackColor = System.Drawing.Color.White;
            this.aboutUs1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.aboutUs1.Location = new System.Drawing.Point(0, 0);
            this.aboutUs1.Name = "aboutUs1";
            this.aboutUs1.Size = new System.Drawing.Size(1080, 664);
            this.aboutUs1.TabIndex = 0;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1292, 764);
            this.Controls.Add(this.panelData);
            this.Controls.Add(this.panelTop);
            this.Controls.Add(this.panelSideBar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dash Board";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.panelLogo.ResumeLayout(false);
            this.panelSideBar.ResumeLayout(false);
            this.panelData.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.Panel panelSideBar;
        private System.Windows.Forms.Panel panelMini;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button btnAboutUs;
        private System.Windows.Forms.Button btnStockData;
        private System.Windows.Forms.Button btnBillData;
        private System.Windows.Forms.Button btnCreateBill;
        private System.Windows.Forms.Button btnAddProduct;
        private System.Windows.Forms.Button btnDashboard;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Panel panelData;
        private AboutUs aboutUs1;
        private Dashboard dashboard1;
        private AddProduct addProduct1;
        private CreateBill createBill1;
        private BillData billData1;
        private ViewStock viewStock1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}