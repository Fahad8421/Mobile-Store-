﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace MobileShopManagementSys
{
    public partial class AddProduct : UserControl
    {
        public AddProduct()
        {
            InitializeComponent();
        }
        public void ClearData()
        {
            lblID.Text = "";
            txtCompanyName.Text = "";
            txtModel.Text = "";
            txtRam.Text = "";
            txtStorage.Text = "";
            txtqty.Text = "";
            txtCost.Text = "";

        }
        public void LoadData()
        {
            try
            {
                string constring = ConfigurationManager.ConnectionStrings["MyConnection"].ToString();
                SqlConnection con = new SqlConnection(constring);
                DataTable donater = new DataTable();
                con.Open();


                SqlDataAdapter sda = new SqlDataAdapter("select * from tbl_Product ", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridViewAddProduct.DataSource = dt;
                con.Close();
                dataGridViewAddProduct.Visible = true;
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void AddProduct_Load(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtCompanyName.Text == "")
                {
                    string msg1 = "Please Insert Company Name";
                    string msg2 = "Add Product";
                    MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                    DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                    txtCompanyName.Focus();
                    return;
                }
                if (txtModel.Text == "")
                {
                    string msg1 = "Please Insert Product Model";
                    string msg2 = "Add Product";
                    MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                    DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                    txtModel.Focus();
                    return;
                }
                if (txtRam.Text == "")
                {
                    string msg1 = "Please Insert RAM";
                    string msg2 = "Add Product";
                    MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                    DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                    txtRam.Focus();
                    return;
                }
                if (txtStorage.Text == "")
                {
                    string msg1 = "Please Insert Storage";
                    string msg2 = "Add Product";
                    MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                    DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                    txtStorage.Focus();
                    return;
                }
                if (txtqty.Text == "")
                {
                    string msg1 = "Please Insert Quntity of Product";
                    string msg2 = "Add Product";
                    MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                    DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                    txtqty.Focus();
                    return;
                }
                if (txtCost.Text == "")
                {
                    string msg1 = "Please Insert Cost of Product'";
                    string msg2 = "Add Product";
                    MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                    DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                    txtCost.Focus();
                    return;
                }
                string constring = ConfigurationManager.ConnectionStrings["MyConnection"].ToString();
                SqlConnection con = new SqlConnection(constring);

                string sql = "insert into tbl_Product values(@cname,@date,@model,@ram,@storage,@qty,@price)";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@cname", txtCompanyName.Text);
                cmd.Parameters.AddWithValue("@date", Calender.Text);
                cmd.Parameters.AddWithValue("@model", txtModel.Text);
                cmd.Parameters.AddWithValue("@ram", txtRam.Text);
                cmd.Parameters.AddWithValue("@storage", txtStorage.Text);
                cmd.Parameters.AddWithValue("@qty", txtqty.Text);
                cmd.Parameters.AddWithValue("@price", txtCost.Text);


                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                int x = cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show(x.ToString() + "Record Inserted");
                ClearData();
                LoadData();
                dataGridViewAddProduct.Update();
                dataGridViewAddProduct.Refresh();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void dataGridViewAddProduct_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            lblID.Text = dataGridViewAddProduct.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtCompanyName.Text = dataGridViewAddProduct.Rows[e.RowIndex].Cells[1].Value.ToString();
            // txtqt.Text = DGAddtoCard.Rows[e.RowIndex].Cells[2].Value.ToString();
            Calender.Text = dataGridViewAddProduct.Rows[e.RowIndex].Cells[2].Value.ToString();
            txtModel.Text = dataGridViewAddProduct.Rows[e.RowIndex].Cells[3].Value.ToString();
            txtRam.Text = dataGridViewAddProduct.Rows[e.RowIndex].Cells[4].Value.ToString();
            txtStorage.Text = dataGridViewAddProduct.Rows[e.RowIndex].Cells[5].Value.ToString();
            txtqty.Text = dataGridViewAddProduct.Rows[e.RowIndex].Cells[6].Value.ToString();
            txtCost.Text = dataGridViewAddProduct.Rows[e.RowIndex].Cells[7].Value.ToString();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            try
            {
                if (lblID.Text == "")
                {
                    string msg1 = "Please Select Data from table";
                    string msg2 = "Add Product";
                    MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                    DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);

                    return;
                }

                if (txtCompanyName.Text == "")
                {
                    string msg1 = "Please Insert Company Name";
                    string msg2 = "Add Product";
                    MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                    DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                    txtCompanyName.Focus();
                    return;
                }
                if (txtModel.Text == "")
                {
                    string msg1 = "Please Insert Product Model";
                    string msg2 = "Add Product";
                    MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                    DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                    txtModel.Focus();
                    return;
                }
                if (txtqty.Text == "")
                {
                    string msg1 = "Please Insert Quntity of Product";
                    string msg2 = "Add Product";
                    MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                    DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                    txtqty.Focus();
                    return;
                }
                if (txtCost.Text == "")
                {
                    string msg1 = "Please Insert Cost of Product'";
                    string msg2 = "Add Product";
                    MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                    DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                    txtCost.Focus();
                    return;
                }
                string constring = ConfigurationManager.ConnectionStrings["MyConnection"].ToString();
                SqlConnection con = new SqlConnection(constring);

                string sql = "update tbl_Product set cname=@cname,date=@date,model=@model,ram=@ram,storage=@storage,qty=@qty,price=@price where pid=@pid";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@pid", lblID.Text);
                cmd.Parameters.AddWithValue("@cname", txtCompanyName.Text);
                cmd.Parameters.AddWithValue("@date", Calender.Text);
                cmd.Parameters.AddWithValue("@model", txtModel.Text);
                cmd.Parameters.AddWithValue("@ram", txtRam.Text);
                cmd.Parameters.AddWithValue("@storage", txtStorage.Text);
                cmd.Parameters.AddWithValue("@qty", txtqty.Text);
                cmd.Parameters.AddWithValue("@price", txtCost.Text);


                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                int x = cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show(x.ToString() + "Record Updated");
                ClearData();
                LoadData();
                dataGridViewAddProduct.Update();
                dataGridViewAddProduct.Refresh();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (lblID.Text == "")
                {
                    string msg1 = "Please Select Data from table";
                    string msg2 = "Add Product";
                    MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                    DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);

                    return;
                }
                string constring = ConfigurationManager.ConnectionStrings["MyConnection"].ToString();
                SqlConnection con = new SqlConnection(constring);

                string sql = "delete tbl_Product where pid=@pid";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@pid", lblID.Text);

                if (con.State != ConnectionState.Open)
                {
                    con.Open();
                }
                int x = cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show(x.ToString() + "Record Deleted");
                ClearData();
                LoadData();
                dataGridViewAddProduct.Update();
                dataGridViewAddProduct.Refresh();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnNewEntry_Click(object sender, EventArgs e)
        {
            ClearData();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtCompanyName.Text == "")
                {
                    string msg1 = "Please Insert Company Name";
                    string msg2 = "Add Product";
                    MessageBoxButtons btn = MessageBoxButtons.OKCancel;
                    DialogResult rs = MessageBox.Show(msg1, msg2, btn, MessageBoxIcon.Error);
                    txtCompanyName.Focus();
                    return;
                }

                string constring = ConfigurationManager.ConnectionStrings["MyConnection"].ToString();
                SqlConnection con = new SqlConnection(constring);
                DataTable donater = new DataTable();
                con.Open();


                SqlDataAdapter sda = new SqlDataAdapter("select * from tbl_Product where cname='" + txtCompanyName.Text + "'", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridViewAddProduct.DataSource = dt;
                con.Close();
                dataGridViewAddProduct.Visible = true;
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btnShowAll_Click(object sender, EventArgs e)
        {
            try
            {
                string constring = ConfigurationManager.ConnectionStrings["MyConnection"].ToString();
                SqlConnection con = new SqlConnection(constring);
                DataTable donater = new DataTable();
                con.Open();


                SqlDataAdapter sda = new SqlDataAdapter("select * from tbl_Product", con);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                dataGridViewAddProduct.DataSource = dt;
                con.Close();
                dataGridViewAddProduct.Visible = true;
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void txtqty_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;

            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void txtCost_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;

            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
    }
}
